


BrowserAutoFillView v1.00
Copyright (c) 2024 Nir Sofer
Web site: https://www.nirsoft.net/utils/web_browser_autofill_view.html



Description
===========

When you fill a form in your Web browser, the Web browser automatically
stores the text you filled in a database, and allows you to automatically
fill the same text again when it's needed (Also known as 'AutoFill'
feature).
BrowserAutoFillView is a simple tool for Windows that displays the text
you previously filled in a form on Chrome and Firefox Web browsers. For
every form text entry, the following information is displayed: Name,
Value, Created Time, Last Used Time, Count, Web browser, Profile Path.

You can also export the autofill list to csv/tab-delimited/html/xml file,
or copy the autofill entries to the clipboard and then paste them to
Excel or other spreadsheet application



System Requirements
===================


* This tool works on any version of Windows, starting from Windows XP
  and up to Windows 11. Both 32-bit and 64-bit systems are supported.
* This tool is just a small standalone .exe file that you can run on
  any system without installing anything.



Supported Web Browsers
======================

BrowserAutoFillView automatically detects and scans the autofill data of
the following Web browsers: Chrome, Firefox, Edge, Opera, Brave, Pale
Moon, SeaMonkey, Waterfox, Vivaldi.
Even if your Web browser is not in the list, but it's based on Chrome or
Firefox, you can try to load its AutoFill list, by choosing the 'Load
autofill data from the specified Web browser profile folders' option in
the 'Advanced Options' window, and then typing the profile folder of your
Web browser.



Start Using BrowserAutoFillView
===============================

BrowserAutoFillView doesn't require any installation process or
additional DLL files. In order to start using it, simply run the
executable file - BrowserAutoFillView.exe

After running BrowserAutoFillView, it scans the AutoFill entries of all
Web browsers on your system and then displays them in the main window of
BrowserAutoFillView.
If you want to view the AutoFill entries on remote network computer (with
admin access) or on external hard drive, go to the 'Advanced Options'
window (F9), and choose the desired data source.



Command-Line Options
====================



/cfg <Filename>
Start BrowserAutoFillView with the specified configuration file. For
example:
BrowserAutoFillView.exe /cfg "c:\config\bafv.cfg"

/DataSource [1 - 6]
/SourceFolder [Folder]
/ComputerName [Name]
.
.
.

You can use any variable inside the .cfg file in order to set the
configuration from command line, here's some examples:

Load the Web browser AutoFill Data from remote computer 192.168.0.100:
BrowserAutoFillView.exe /DataSource 5 /ComputerName 192.168.0.100

Load the Web browser AutoFill Data from K:\Users folder
BrowserAutoFillView.exe /DataSource 3 /SourceFolder "K:\Users"

/stext <Filename>
Save the Web browser AutoFill data to a simple text file.

/stab <Filename>
Save the Web browser AutoFill data to a tab-delimited text file.

/scomma <Filename>
Save the Web browser AutoFill data to a comma-delimited text file (csv).

/shtml <Filename>
Save the Web browser AutoFill data to HTML5 file (Horizontal).

/sverhtml <Filename>
Save the Web browser AutoFill data to HTML5 file (Vertical).

/sxml <Filename>
Save the Web browser AutoFill data to XML file.

/sjson <Filename>
Save the Web browser AutoFill data to JSON file.



Translating BrowserAutoFillView to other languages
==================================================

In order to translate BrowserAutoFillView to other language, follow the
instructions below:
1. Run BrowserAutoFillView with /savelangfile parameter:
   BrowserAutoFillView.exe /savelangfile
   A file named BrowserAutoFillView_lng.ini will be created in the folder
   of BrowserAutoFillView utility.
2. Open the created language file in Notepad or in any other text
   editor.
3. Translate all string entries to the desired language. Optionally,
   you can also add your name and/or a link to your Web site.
   (TranslatorName and TranslatorURL values) If you add this information,
   it'll be used in the 'About' window.
4. After you finish the translation, Run BrowserAutoFillView, and all
   translated strings will be loaded from the language file.
   If you want to run BrowserAutoFillView without the translation, simply
   rename the language file, or move it to another folder.



License
=======

This utility is released as freeware. You are allowed to freely
distribute this utility via CD-ROM, DVD, Internet, or in any other way,
as long as you don't charge anything for this and you don't sell it or
distribute it as a part of commercial product. If you distribute this
utility, you must include all files in the distribution package, without
any modification !



Disclaimer
==========

The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be liable for any special, incidental, consequential or indirect damages
due to loss of data or any other reason.



Feedback
========

If you have any problem, suggestion, comment, or you found a bug in my
utility, you can send a message to support@nirsoft.net
