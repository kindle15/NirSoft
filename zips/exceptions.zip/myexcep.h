int ShowExceptionDlg(EXCEPTION_POINTERS *ep);
void ExceptionFunction();
void CenterWindow(HWND hwndDlg);

