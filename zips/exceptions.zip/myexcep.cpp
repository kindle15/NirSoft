#include <windows.h>
#include <winnt.h>
#include <stdio.h>
#include "myexcep.h"
#include "resource.h"


EXCEPTION_RECORD CurrExceptionRecord;
CONTEXT CurrContext;
int iLastExceptionDlgResult;
HINSTANCE hCurrInstance;

void SetCurrInstance(HINSTANCE hInst)
{
	hCurrInstance = hInst;
}

HINSTANCE GetCurrInstance()
{
	return hCurrInstance;
}


void CopyEditToClipboard(HWND hWnd)
{
	SendMessage(hWnd, EM_SETSEL, 0, 65535L);
	SendMessage(hWnd, WM_COPY, 0 , 0);
	SendMessage(hWnd, EM_SETSEL, 0, 0);
}

void GetScreenSize(int *pWidth, int *pHeight)
{
	HDC hDC;
	hDC = GetDC(0);
	if (pWidth != NULL) *pWidth = GetDeviceCaps(hDC, HORZRES);
	if (pHeight != NULL ) *pHeight = GetDeviceCaps(hDC, VERTRES);
	ReleaseDC(0, hDC);
}

void CenterWindow(HWND hwndDlg)
{
	int nWidth, nHeight, nLeft, nTop;
	RECT rcWin;

	GetScreenSize(&nWidth, &nHeight);
	GetWindowRect(hwndDlg, &rcWin);
	
	nLeft = (nWidth - (rcWin.right - rcWin.left + 1)) / 2;
	nTop = (nHeight - (rcWin.bottom - rcWin.top + 1)) / 2;

	MoveWindow(hwndDlg, nLeft, nTop, rcWin.right - rcWin.left + 1, rcWin.bottom - rcWin.top + 1, TRUE);
}


BOOL CALLBACK ExceptionFilterFunctionDlgProc(
  HWND hwndDlg,  // handle to dialog box
  UINT uMsg,     // message
  WPARAM wParam, // first message parameter
  LPARAM lParam  // second message parameter
)
{
	WORD wNotifyCode, wID;
	
	switch(uMsg)
	{
		case WM_INITDIALOG:
			{
				CenterWindow(hwndDlg);
				char szBuffer[2048] = "";
				
				sprintf(szBuffer, 
				"Exception %8.8X at address %8.8X\r\nRegisters: \r\nEAX=%8.8X EBX=%8.8X ECX=%8.8X EDX=%8.8X\r\nESI=%8.8X EDI=%8.8X EBP=%8.8X ESP=%8.8X\r\nEIP=%8.8X", 
				CurrExceptionRecord.ExceptionCode, CurrExceptionRecord.ExceptionAddress,
				CurrContext.Eax,
				CurrContext.Ebx,
				CurrContext.Ecx,
				CurrContext.Edx,
				CurrContext.Esi,
				CurrContext.Edi,
				CurrContext.Ebp,
				CurrContext.Esp,
				CurrContext.Eip
				);
				SetDlgItemText(hwndDlg, IDC_EXCEPTION_DETAILS, szBuffer);

				SetFocus(GetDlgItem(hwndDlg, IDC_EXCEPTION_DETAILS));

			}
			break;
	
		case WM_COMMAND:
			wNotifyCode = HIWORD(wParam); // notification code 
			wID = LOWORD(wParam);         // item, control, or accelerator identifier 
			if (wNotifyCode == BN_CLICKED)
			{
				if (wID == IDOK || wID == IDCANCEL)
					EndDialog(hwndDlg, wID);

				if (wID == IDC_COPY_EXCEPTION)
					CopyEditToClipboard(GetDlgItem(hwndDlg, IDC_EXCEPTION_DETAILS));


			}

			break;
	}

	return FALSE;
}

void ExceptionFunction()
{
	if (iLastExceptionDlgResult == IDCANCEL)
	{
		//If the user selects "Terminate Application", exit from the program.
		ExitProcess(1);
	}
}

int ShowExceptionDlg(EXCEPTION_POINTERS *ep)
{
	memcpy(&CurrExceptionRecord, ep->ExceptionRecord, sizeof(EXCEPTION_RECORD));
	memcpy(&CurrContext, ep->ContextRecord, sizeof(CONTEXT));

	//Show our exception dialog-box
	iLastExceptionDlgResult = DialogBoxParam(GetCurrInstance(), MAKEINTRESOURCE(IDD_EXCEPTION), 0, ExceptionFilterFunctionDlgProc, 0);

	//return 1 in order to continue to run the program after the exception handling.			
	return 1;
}
