#include <windows.h>
#include "myexcep.h"
#include "resource.h"

void DoException()
{
	//This function causes an exception by trying to read from invalid memory address. 
	
	char *pAddress = NULL;
	pAddress[0] = 0;
}


void HandledExceptionTest()
{
	__try
	{
		//This function causes the exception
		DoException();
	}
	//If an exception is occurred, display our exception dialog:
	__except(ShowExceptionDlg(GetExceptionInformation())) 
	{
		ExceptionFunction();
	}

}

void UnhandledExceptionTest()
{
	//This function causes the exception. 
	//Because there is not exception handling here, the program will crash.
	DoException();
}


BOOL CALLBACK MainDialogProc(
  HWND hwndDlg,  // handle to dialog box
  UINT uMsg,     // message
  WPARAM wParam, // first message parameter
  LPARAM lParam  // second message parameter
)
{
	WORD wNotifyCode, wID;
	
	switch(uMsg)
	{
		case WM_INITDIALOG:
			CenterWindow(hwndDlg);
			break;

		case WM_COMMAND:
			wNotifyCode = HIWORD(wParam); // notification code 
			wID = LOWORD(wParam);         // item, control, or accelerator identifier 
			if (wNotifyCode == BN_CLICKED)			
			{
				if (wID == IDC_WITHOUT_EXCEPTION_HANDLING)	
					UnhandledExceptionTest();

				if (wID == IDC_WITH_EXCEPTION_HANDLING)
					HandledExceptionTest();

				if (wID == IDC_EXIT)
					EndDialog(hwndDlg, 0);
			}


			return TRUE;

	}


	return FALSE;
}

int WINAPI WinMain(
  HINSTANCE hInstance,      // handle to current instance
  HINSTANCE hPrevInstance,  // handle to previous instance
  LPSTR lpCmdLine,          // command line
  int nCmdShow              // show state
)
{
	//Display the main dialog-box
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_MAIN), NULL, MainDialogProc);

	return 0;
}