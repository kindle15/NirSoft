//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDC_COPY_EXCEPTION              3
#define IDD_DIALOG1                     101
#define IDD_MAIN                        102
#define IDD_EXCEPTION                   107
#define IDC_WITHOUT_EXCEPTION_HANDLING  1000
#define IDC_WITH_EXCEPTION_HANDLING     1001
#define IDC_EXCEPTION_DETAILS           1002
#define IDC_EXIT                        1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
