


WhoisThisDomain v1.52
Copyright (c) 2005 - 2010 Nir Sofer
Web site: http://www.nirsoft.net



Description
===========

This utility allows you to easily get information about a registered
domain. It automatically connect to the right WHOIS server, according to
the top-level domain name, and retrieve the WHOIS record of the domain.
It support both generic domains and country code domains.



System Requirements
===================


* Windows operating system: Any version of Windows, from Windows 98 and
  up to Windows 7.
* Internet connection.
* On a firewall, you should allow outgoing connections to port 43.



Versions History
================


* Version 1.52
  o Added support for .tz domains.

* Version 1.51
  o Fixed bug: WhoisThisDomain always displayed .at domain as
    registered.

* Version 1.50
  o Fixed bug for .info and .org domains: When 'Remove Top Whois
    Lines' option was turned on, a few significant lines in the top were
    missing.
  o WhoisThisDomain now detect the expire/update/created dates for
    .info, .org, and .biz domains.

* Version 1.47 - Fixed the WHOIS server for .tw domains and added WHOIS
  server for .asia domains.
* Version 1.46 - Fixed bug in the new 'pause' feature: If you set the
  'pause' to more than 20 seconds, WhoisThisDomain displayed the last
  domain as 'Failed' and continue to the next one.
* Version 1.45 - Added 'pause' option, which allows you to pause the
  domains retrieval after xx domains, so you won't be blocked by the
  WHOIS servers.
* Version 1.41 - Added support for .pr domains.
* Version 1.40 - Added 3 columns: 'Expires On', 'Created On', and 'Last
  Updated On'. These columns are filled only for domains in major
  .net/.com Registrars (GoDaddy, Network Solutions, and so on).
* Version 1.34 - Fixed the whois server of .ms domains.
* Version 1.33 - Updated the whois servers for .is, .lt, .ma, .md, .pl,
  .si, and .sk domains.
* Version 1.32 - Added/Updated the whois servers for .in, .ie, .me,
  .tel, and co.nl domains.
* Version 1.31 - Fixed bug: Wrong domain status displayed for .ca and
  .it domains.
* Version 1.30 - Fixed the whois servers for .at, .be, .bg, .cz, and
  others.
* Version 1.29 - Fixed bug: The size of domains text-box was limited to
  32 KB.
* Version 1.28 - The whois servers file now allows you to specify more
  than one server for country-code level domains. (For example: one
  server for .uk domains and the other server for gov.uk domains)
* Version 1.27 - Fixed the problem WHOIS server of .ro domains and
  fixed the WHOIS server of .cn domains.
* Version 1.26 - Fixed the WHOIS server of .jp domains to whois.jprs.jp
* Version 1.25 - The splitter location is now saved to cfg file.
* Version 1.24 - Fixed bug: The main window lost the focus when the
  user switched to another application and then returned back to
  WhoisThisDomain.
* Version 1.23 - The configuration is now saved to a file, instead of
  the Registry.
* Version 1.22 - Fixed bug: free .eu domains displayed as registered.
* Version 1.21 - Updated the WHOIS server for .com and .net domains (to
  whois.verisign-grs.com) and for .org domain (to whois.pir.org)
* Version 1.20
  o Added 'Build Domains List' option.
  o Added support for external WHOIS servers list - whois-servers.txt
  o Fixed bug: .biz and other domains detected as registered even
    when they are available.
  o Fixed the WHOIS server for .il domains

* Version 1.12 - Fixed the WHOIS server for .tr domains. Fixed bug:
  available .de domains displayed as regsitered.
* Version 1.11 - Added support for .coop domains.
* Version 1.10 - Added support for the following domains: .ws, .vc,
  .uy, .uz, .tp. .tk, .tl, .sa, .sb, .sc, .pro, .nf, .mc, .mu, .la, .ly,
  .ir, .hm, .hn, .gl, .dm, .cd, .bz, .bj, .bi, .ae, .ag, .my, .mobi.,
  .travel
* Version 1.09 - Added support for .my domains, and changed the .nl
  WHOIS server to the new one.
* Version 1.08 - Added support for .nz domains.
* Version 1.07 - Fixed the WHOIS servers for .mx and .br domains
* Version 1.06 - Fixed the WHOIS server for .ve domains.
* Version 1.05 - Fixed the WHOIS server for .pt domains.
* Version 1.04 - Added support for .eu domains.
* Version 1.03 - Added support for .tv domains.
* Version 1.02 - Fixed the problem with French domains.
* Version 1.01 - Fixed the problem with German domains.
* Version 1.00 - First Release.



Using WhoisThisDomain
=====================

This utility doesn't require any installation process or additional DLLs.
Just put the executable file (WhoisTD.exe) anywhere you like, and run it.
When running WhoisThisDomain utility, the "Choose Domains" window
appears. You can type a single domain, or multiple domains separated by
commas, space characters, or enter characters. After pressing the 'OK'
button, WhoisThisDomain start to retrieve the WHOIS records for the
domains that you typed.



Creating whois-servers.txt
==========================

Starting from version 1.20, you can create your own WHOIS servers list to
override the default servers defined by WhoisThisDomain.
In order to use this feature, follow the instructions below:
1. Create a file named 'whois-servers.txt' in the same folder of
   WhoisTD.exe
2. Add the needed servers to the list. Each line should contain the
   domain extension, a space character, and then the whois server
   address. For example:

gov whois.nic.gov
com rs.internic.net 
il whois.isoc.org.il
ir whois.nic.ir


3. In the next time that you run WhoisThisDomain, the specified
   servers will be used instead of the default servers list stored in
   WhoisThisDomain.
Be aware that WhoisThisDomain only supports WHOIS servers in port 43. It
doesn't support Web-based WHOIS requests.



Build Domains List Option
=========================

If you want to check multiple domain names in combinations with multiple
domain extensions, this feature can help you. For example, if you want to
check abcde, poiuyt, lkjhgf names with .com, .org, .net, .biz extensions,
simply type the names list in the first text-box, and the extensions list
in the second one. After you click OK, you'll get the list of all
possible combinations (abcde.com, abcde.org, abcde.net, and so on...)



Translating WhoisThisDomain to other languages
==============================================

WhoisThisDomain allows you to easily translate all menus, dialog-boxes,
and other strings to other languages.
In order to do that, follow the instructions below:
1. Run WhoisThisDomain with /savelangfile parameter:
   WhoisTD.exe /savelangfile
   A file named WhoisTD_lng.ini will be created in the folder of
   WhoisThisDomain utility.
2. Open the created language file in Notepad or in any other text
   editor.
3. Translate all menus, dialog-boxes, and string entries to the
   desired language. Optionally, you can also add your name and/or a link
   to your Web site. (TranslatorName and TranslatorURL values) If you add
   this information, it'll be used in the 'About' window.
4. After you finish the translation, Run WhoisThisDomain, and all
   translated strings will be loaded from the language file.
   If you want to run WhoisThisDomain without the translation, simply
   rename the language file, or move it to another folder.


License
=======

This utility is released as freeware. You are allowed to freely
distribute this utility via floppy disk, CD-ROM, Internet, or in any
other way, as long as you don't charge anything for this. If you
distribute this utility, you must include all files in the distribution
package, without any modification !



Disclaimer
==========

The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be liable for any special, incidental, consequential or indirect damages
due to loss of data or any other reason.



Feedback
========

If you have any problem, suggestion, comment, or you found a bug in my
utility, you can send a message to nirsofer@yahoo.com
