


BootPerformanceView v1.05
Copyright (c) 2020 - 2026 Nir Sofer
Web site: https://www.nirsoft.net/utils/boot_performance_view.html



Description
===========

BootPerformanceView is a tool for Windows 11/10/8/7/Vista that displays
the performance information of the boot process on your system. The
information is taken from the
Microsoft-Windows-Diagnostics-Performance/Operational event log. For
every boot performance record, the following information is displayed:
Boot Start Time, Boot End Time, Boot Time, Main Path Boot Time, Kernel
Init Time, Driver Init Time, Devices Init Time, Smss Init Time, User
Profile Processing Time, and more... You can view the boot performance
information on your local system, on remote network computer, or load it
from external event log file.



System Requirements
===================

This tool works on any version of Windows, starting from Windows Vista
and up to Windows 11. Both 32-bit and 64-bit systems are supported.



Versions History
================


* Version 1.05:
  o Added 'Boot Duration' column, which displays the time difference
    between the 'Boot Start Time' and 'Boot End Time' columns.

* Version 1.00 - First release.



Start Using BootPerformanceView
===============================

BootPerformanceView doesn't require any installation process or
additional DLL files. In order to start using it, simply run the
executable file - BootPerformanceView.exe
After running BootPerformanceView, the main window displays the boot
performance information of the current running system. If you want to
view the boot performance information of another system, go to File ->
Choose Data Source (or simply press F7), and then choose the desired data
source (External events folder or remote computer).



Command-Line options
====================




/stext <Filename>
Save the boot performance records to a simple text file.

/stab <Filename>
Save the boot performance records to a tab-delimited text file.

/scomma <Filename>
Save the boot performance records to a comma-delimited text file (csv).

/shtml <Filename>
Save the boot performance records to HTML5 file (Horizontal).

/sverhtml <Filename>
Save the boot performance records to HTML5 file (Vertical).

/sxml <Filename>
Save the boot performance records to XML file.

/sjson <Filename>
Save the boot performance records to JSON file.

/sort <column>
This command-line option can be used with other save options for sorting
by the desired column. The <column> parameter can specify the column
index (0 for the first column, 1 for the second column, and so on) or the
name of the column, like "Record ID" and "Boot Start Time". You can
specify the '~' prefix character (e.g: "~Boot Time") if you want to sort
in descending order. You can put multiple /sort in the command-line if
you want to sort by multiple columns.

/cfg <Config Filename&gt
Start BootPerformanceView with the specified config file.

/Columns <Comma Delimited Columns List>
Allows you to set the columns to display or the columns to export from
command-line. You have to specify the column names, delimited by comma,
for example:
BootPerformanceView.exe /scomma c:\temp\boot-performance.csv /Columns
"Record ID,Boot Start Time,Boot End Time,Boot Time"

You can also specify the column names without space characters, for
example:
BootPerformanceView.exe /Columns
"RecordID,BootStartTime,BootEndTime,BootTime"



Translating BootPerformanceView to other languages
==================================================

In order to translate BootPerformanceView to other language, follow the
instructions below:
1. Run BootPerformanceView with /savelangfile parameter:
   BootPerformanceView.exe /savelangfile
   A file named BootPerformanceView_lng.ini will be created in the folder
   of BootPerformanceView utility.
2. Open the created language file in Notepad or in any other text
   editor.
3. Translate all string entries to the desired language. Optionally,
   you can also add your name and/or a link to your Web site.
   (TranslatorName and TranslatorURL values) If you add this information,
   it'll be used in the 'About' window.
4. After you finish the translation, Run BootPerformanceView, and all
   translated strings will be loaded from the language file.
   If you want to run BootPerformanceView without the translation, simply
   rename the language file, or move it to another folder.



License
=======

This utility is released as freeware. You are allowed to freely
distribute this utility via CD-ROM, DVD, Internet, or in any other way,
as long as you don't charge anything for this and you don't sell it or
distribute it as a part of commercial product. If you distribute this
utility, you must include all files in the distribution package, without
any modification !



Disclaimer
==========

The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be liable for any special, incidental, consequential or indirect damages
due to loss of data or any other reason.



Feedback
========

If you have any problem, suggestion, comment, or you found a bug in my
utility, you can send a message to support@nirsoft.net
