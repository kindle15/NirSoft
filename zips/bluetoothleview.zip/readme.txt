


BluetoothLEView v1.02
Copyright (c) 2025 Nir Sofer
Web site: https://www.nirsoft.net/utils/bluetooth_low_energy_scanner.html



Description
===========

BluetoothLEView is a tool for Windows 10 and Windows 11 that monitors the
activity of Bluetooth Low Energy devices around you. For every detected
device, the following information is displayed (if it's available): MAC
Address, Name, Signal Strength In dBm (RSSI), Manufacturer ID,
Manufacturer Name, Service UUID, first and last time that the device was
detected, number of times that the device was detected, and more...



System Requirements
===================


* This tool works on Windows 10 and Windows 11. Both 32-bit and 64-bit
  systems are supported.
* This tool is just a small standalone .exe file that you can run on
  any system without installing anything.
* Bluetooth dongle that supports Bluetooth Low Energy is needed for
  this tool.



Versions History
================


* Version 1.02:
  o Added 'Clear All' toolbar button.

* Version 1.01:
  o Added new option: Display only devices detected in the last xx
    seconds (In the 'Advanced Options' window).

* Version 1.00 - First release.



Start Using BluetoothLEView
===========================

BluetoothLEView doesn't require any installation process or additional
DLL files. In order to start using it, simply run the executable file -
BluetoothLEView.exe
After running it, BluetoothLEView activates the Bluetooth Low Energy
scanner and displays every device that it finds.

While BluetoothLEView is running you can use the following options:
* Stop and start again the Bluetooth Low Energy scanning by using the
  'Stop Monitor Bluetooth' (F8 key) and the 'Start Monitor Bluetooth' (F7
  key) options.
* Use the 'Save All Items' option (Shift+Ctrl+S) to export the
  displayed devices to csv/tab-delimited/xml/html5/JSON file. You can
  also use the 'Save Selected Items' option to export only the selected
  devices.
* Select one or more devices, copy the devices list to the clipboard
  (Ctrl+C) and then paste them to Excel or any other application.
* Turn on the 'Put Icon On Tray' option, close the main window, and
  allow BluetoothLEView to monitor the Bluetooth Low Energy devices in
  the background.
* Use the 'Clear All' option (Ctrl+X) to clear the devices list
  collected until now.



Icon Color
==========

The color of the icon displayed for every device is based on the signal
strength (RSSI). The color scale starts from green (good RSSI value,
device is very close) and finishes in red-purple (bad RSSI value, device
is too far).



Lower Pane
==========

When you select a device in the upper pane, the lower pane displays raw
data from this device, in 'Hex Dump' format. If you don't need this
feature, you can hide the lower pane from View Menu -> Show Lower Pane.



BluetoothLEView Columns
=======================


* MAC Address: The MAC Address of the device. The address may be public
  or random. (see the 'Address Type' column)
* Name: The name of the device, available only if it's published by the
  device.
* RSSI: The signal strength in dBm.
* Manufacturer ID: Manufacturer ID of the device. You can find the list
  of all manufacturer IDs in the following link:
  https://bitbucket.org/bluetooth-SIG/public/src/main/assigned_numbers/comp
  any_identifiers/company_identifiers.yaml
* Manufacturer Name: The name of the manufacturer according to the
  Manufacturer ID.
* Advertisement Type: Connectable Undirected, Connectable Directed,
  Scannable Undirected, Non-Connectable Undirected, Scan Response,
  Extended
* Advertisement Flags: Contains one or more of the following flags:
  Limited Discoverable Mode, General Discoverable Mode, Classic Not
  Supported, Dual Mode Controller Capable, Dual Mode Host Capable
* Service UUID: List of 128-bit service UUIDs.
* Service ID: List of 16-bit service IDs. You can find a list of known
  service IDs is in the following link:
  https://bitbucket.org/bluetooth-SIG/public/src/main/assigned_numbers/uuid
  s/service_uuids.yaml
* Service Name: Name of service according to the 16-bit service ID.
* Counter: The number of times that the device was detected.
* First Detected On: The first time that the device was detected.
* Last Detected On: The last time that the device was detected.
* Transmit Power Level: Transmit power level in dBm. This value is only
  available if it's published by the device.
* Address Type: The type of the MAC address: Public, Random, or
  Unspecified.
* MAC Address Company: The name of company/manufacturer according to
  the MAC address. In order to use this column you have to download the
  MAC addresses database and put it in the same folder of BluetoothLEView
  (as oui.txt): https://standards-oui.ieee.org/oui/oui.txt



Command-Line Options
====================



/CaptureTime <Milliseconds>
Specifies the capture time in milliseconds for the save command-line
options (/stext, /stab, /scomma, and so on...) The default is 10000
milliseconds (10 seconds).

/stext <Filename>
Save the Bluetooth Low Energy devices to a simple text file.

/stab <Filename>
Save the Bluetooth Low Energy devices to a tab-delimited text file.

/scomma <Filename>
Save the Bluetooth Low Energy devices to a comma-delimited text file
(csv).

/shtml <Filename>
Save the Bluetooth Low Energy devices to HTML5 file (Horizontal).

/sverhtml <Filename>
Save the Bluetooth Low Energy devices to HTML5 file (Vertical).

/sxml <Filename>
Save the Bluetooth Low Energy devices to XML file.

/sjson <Filename>
Save the Bluetooth Low Energy devices to JSON file.

/sort <column>
This command-line option can be used with other save options for sorting
by the desired column. The <column> parameter can specify the column
index (0 for the first column, 1 for the second column, and so on) or the
name of the column, like "Name" and "RSSI". You can specify the '~'
prefix character (e.g: "~Manufacturer ID") if you want to sort in
descending order. You can put multiple /sort in the command-line if you
want to sort by multiple columns.

/cfg <Config Filename&gt
Start BluetoothLEView with the specified config file.

/Columns <Comma Delimited Columns List>
Allows you to set the columns to display or the columns to export from
command-line. You have to specify the column names, delimited by comma,
for example:
BluetoothLEView.exe /shtml c:\temp\ble-devices.html /Columns "MAC
Address,Name,RSSI,Manufacturer ID,Manufacturer Name"

You can also specify the column names without space characters, for
example:
BluetoothLEView.exe /Columns
"MACAddress,Name,RSSI,ManufacturerID,ManufacturerName"



Translating BluetoothLEView to other languages
==============================================

In order to translate BluetoothLEView to other language, follow the
instructions below:
1. Run BluetoothLEView with /savelangfile parameter:
   BluetoothLEView.exe /savelangfile
   A file named BluetoothLEView_lng.ini will be created in the folder of
   BluetoothLEView utility.
2. Open the created language file in Notepad or in any other text
   editor.
3. Translate all string entries to the desired language. Optionally,
   you can also add your name and/or a link to your Web site.
   (TranslatorName and TranslatorURL values) If you add this information,
   it'll be used in the 'About' window.
4. After you finish the translation, Run BluetoothLEView, and all
   translated strings will be loaded from the language file.
   If you want to run BluetoothLEView without the translation, simply
   rename the language file, or move it to another folder.



License
=======

This utility is released as freeware. You are allowed to freely
distribute this utility via CD-ROM, DVD, Internet, or in any other way,
as long as you don't charge anything for this and you don't sell it or
distribute it as a part of commercial product. If you distribute this
utility, you must include all files in the distribution package, without
any modification !



Disclaimer
==========

The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be liable for any special, incidental, consequential or indirect damages
due to loss of data or any other reason.



Feedback
========

If you have any problem, suggestion, comment, or you found a bug in my
utility, you can send a message to support@nirsoft.net
