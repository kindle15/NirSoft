#ifndef _VOLUMOUSEPLUGIN_H_
#define _VOLUMOUSEPLUGIN_H_

/*
Volumouse Plugins Header File

This header file is needed for creating plugins for Volumouse utility.

Volumouse Web Page:
http://www.nirsoft.net/utils/volumouse.html

General guidelines for Volumouse plugins:

* The main entry point that receive all events from Volumouse must be defined as follows:
INT_PTR WINAPI VolumousePluginProc(VOLUMOUSE_PLUGIN_EVENT *pEvent)
{

}

* This function must be exported as 'VolumousePluginProc', without c++ name mangling
  You can do that, by adding VolumousePluginProc to the exports section of the .DEF file.

* When an event is handled, you should return TRUE value. otherwise, you should return a FALSE value.

* Any string that you pass to pEvent parameter must be global. You should not pass a string from your local stack. 
  If you do that, Volumouse may crash.

* In order to activate the plugin, you should change the file extension from .dll to .vpl (Volumouse Plugin Library)
  and drop it into the folder of Volumouse. 


*/

//Maximum number of components that a single plugin can add.
#define VOLUPLUGIN_MAX_COMPONENTS 16


/*************************************************
Volumouse Events
*************************************************/

/*
Load event - called when the plugin is loaded into Volumouse.
You should set the pointer of pEvent->Load.PluginName to your plugin name string (in Unicode)
*/
#define VOLUPLUGIN_EVENT_LOAD 1


/*
Add Components event - called when Volumouse fills the components combo-box
You should set the pEvent->AddComponents.Count to the number of components (no more than VOLUPLUGIN_MAX_COMPONENTS)
And set the pEvent->AddComponents.Components array to point to the component names.
*/
#define VOLUPLUGIN_EVENT_ADD_COMPONENTS 2


/*
User Action event - called when the user moves the mouse wheel or press the
appropriate hot keys, according to the defined rules in Volumouse.
You'll receive this event only if the selected component is one of the 
components that you added in VOLUPLUGIN_EVENT_ADD_COMPONENTS event.

pEvent->UserAction.RuleIndex contains the index of the rule that fired the event.
pEvent->UserAction.ComponentIndex contains the component index that you added with VOLUPLUGIN_EVENT_ADD_COMPONENTS event. 
pEvent->UserAction.Change contains a value that represents the mouse wheel moves.
positive value - increase, negative value - decrease. This value is also affected
by the "Steps" parameters selected by the user. For example: if the user
selects "1000" as the steps value, you'll get '1000' (or -1000) value for each single wheel move. 

pEvent->UserAction.UserSteps - The number of steps defined by user (The default is 1000)
pEvent->UserAction.IndicatorValue - You should set this variable to a number
between 0 (VOLUPLUGIN_INDICATOR_MIN) and 32767 (VOLUPLUGIN_INDICATOR_MAX)
This number affects the indicator displayed on the screen. 0 = 0%, 32767 = 100%
*/
#define VOLUPLUGIN_EVENT_USER_ACTION 3


/*
This event is called when a plugin is unloaded
You can use this event to release memory or resources allocated by the plugin.
*/
#define VOLUPLUGIN_EVENT_UNLOAD 255

#define VOLUPLUGIN_INDICATOR_MIN 0
#define VOLUPLUGIN_INDICATOR_MAX 32767

typedef struct _VOLUMOUSE_PLUGIN_EVENT
{
	DWORD EventID;
	PVOID Reserved;
	union 
	{
		struct 
		{
			DWORD Count;
			LPWSTR Components[VOLUPLUGIN_MAX_COMPONENTS];
		} AddComponents;

		struct 
		{
			LPWSTR PluginName;
		} Load;

		struct
		{
			DWORD RuleIndex;
			DWORD ComponentIndex;
			INT Change;
			INT UserSteps;
			DWORD IndicatorValue;
		} UserAction;
	};
} VOLUMOUSE_PLUGIN_EVENT, *PVOLUMOUSE_PLUGIN_EVENT;



//The name of the main entry point function of Volumouse
#define VOLUMOUSEPLUGINPROC_NAME "VolumousePluginProc"

//typedef of the main entry point function of Volumouse
typedef INT_PTR (WINAPI *VOLUMOUSEPLUGINPROC)(VOLUMOUSE_PLUGIN_EVENT *pEvent);


#endif