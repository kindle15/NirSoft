#include <windows.h>
#include "VolumousePlugin.h"


/*
Sample for creating a plugin for Volumouse.

This sample adds 2 compnents to Volumouse:
Desktop Color - changes the color of your desktop in gray scale (from black to white), assuming that you don't have a wallpaper in your desktop.
Window Color -  changes the backgroud color of windows in gray scale (from black to white)

After you exit from Volumouse, and the addin is unloaded, these 2 colors will return back to normal.

This plugin is not very useful, it was created just for demonstrating how to develop a plugin.

Be aware that this sample may cause a pretty severe flickering on your screen !!!


In order to view how this sample works:

1. Build this project as release. 

2. Copy VoluSample.vpl to the folder of Volumouse.

3. Run Volumouse, and you should see 2 new components: 'Desktop Color' and 'Window Color'.

4. Create a new rule with one of these components.

5. scroll the mouse wheel according to the rule that you created, and watch the show...

6. In order to return back to normal, exit from Volumouse, and delete the plug file.



*/

BOOL WINAPI DllMain(
  HINSTANCE hinstDLL,
  DWORD fdwReason,
  LPVOID lpvReserved
)
{

	return TRUE;
}

WCHAR PluginName[] = L"Sample Plugin";
WCHAR DesktopComponentName[] = L"Desktop Color";
WCHAR WindowComponentName[] = L"Window Color";

COLORREF LastWindowColor;
COLORREF LastDesktopColor;

float CurrentDesktopValue = 128;
float CurrentWindowValue = 128;


void SetSysColor(int index, COLORREF color)
{
	if (GetSysColor(index) != color)
	{
		int elements[] = {index};
		COLORREF colors[] = {color};

		SetSysColors(1, elements, colors);
	}
}

void UpdateSystemColor(VOLUMOUSE_PLUGIN_EVENT *pEvent, float *pColorValue, int colorIndex)
{
	//Change the color value according to the wheel moves.
	*pColorValue += pEvent->UserAction.Change / 200;
	
	//Ensure that the value is always between 0 and 255.
	if (*pColorValue > 255)
		*pColorValue = 255;

	if (*pColorValue < 0)
		*pColorValue  = 0;

	//Set the desktop or window color.
	SetSysColor(colorIndex, RGB(*pColorValue, *pColorValue, *pColorValue));

	//Update the indicator value.
	pEvent->UserAction.IndicatorValue = (int)(VOLUPLUGIN_INDICATOR_MAX * (*pColorValue) / 255);
	
}

INT_PTR WINAPI VolumousePluginProc(VOLUMOUSE_PLUGIN_EVENT *pEvent)
{
	INT_PTR result = FALSE;

	switch(pEvent->EventID)
	{
		case VOLUPLUGIN_EVENT_LOAD:
			//This event is fired when the plugin is loaded into Volumouse.
			//Set the current window and desktop colors, so we'll
			//be able to return them back to normal after the plugin is unloaded.
			LastWindowColor = GetSysColor(COLOR_WINDOW);
			LastDesktopColor = GetSysColor(COLOR_DESKTOP);

			pEvent->Load.PluginName = PluginName;
			result = TRUE;


			break;

		case VOLUPLUGIN_EVENT_UNLOAD:
			//This event is fired when the plugin is unloaded from Volumouse.
			//Set back the original desktop and window colors.
			SetSysColor(COLOR_DESKTOP, LastDesktopColor);
			SetSysColor(COLOR_WINDOW, LastWindowColor);
			result = TRUE;


			break;

		case VOLUPLUGIN_EVENT_ADD_COMPONENTS:
			//This event is fired when Volumouse need to display the components list.
			//Add our 2 components to the components list of Volumouse.
			pEvent->AddComponents.Count = 2;
			pEvent->AddComponents.Components[0] = DesktopComponentName;
			pEvent->AddComponents.Components[1] = WindowComponentName;
			
			result = TRUE;


			break;

		case VOLUPLUGIN_EVENT_USER_ACTION:
			//This event is fired when the user moves the wheel or press
			//the hot key combination, according to the defined rules.

			//If it's component no. 0, update the desktop color.
			//If it's component no. 1, update the window color.
			if (pEvent->UserAction.ComponentIndex == 0)
				UpdateSystemColor(pEvent, &CurrentDesktopValue, COLOR_DESKTOP);
			else if (pEvent->UserAction.ComponentIndex == 1)
				UpdateSystemColor(pEvent, &CurrentWindowValue, COLOR_WINDOW);

			result = TRUE;

			break;
	}

	return result;
}