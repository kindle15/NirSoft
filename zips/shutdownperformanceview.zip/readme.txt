


ShutdownPerformanceView v1.05
Copyright (c) 2020 - 2026 Nir Sofer
Web site: https://www.nirsoft.net/utils/shutdown_performance_view.html



Description
===========

ShutdownPerformanceView is a tool for Windows that displays the
performance information of Windows shutdown process. The information is
taken from the Microsoft-Windows-Diagnostics-Performance/Operational
event log. For every Windows shutdown performance record, the following
information is displayed: Shutdown Start Time, Shutdown End Time,
Shutdown Time, User Session Time, User Profiles Time, Services Time, and
more... You can view the shutdown performance information on your local
system, on remote computer on your network, or load it from external
event log file.



System Requirements
===================

This tool works on any version of Windows, starting from Windows Vista
and up to Windows 11. Both 32-bit and 64-bit systems are supported.



Versions History
================


* Version 1.05:
  o Added 'Shutdown Duration' column, which displays the time
    difference between the 'Shutdown Start Time' and 'Shutdown End Time'
    columns.

* Version 1.00 - First release.



Start Using ShutdownPerformanceView
===================================

ShutdownPerformanceView doesn't require any installation process or
additional DLL files. In order to start using it, simply run the
executable file - ShutdownPerformanceView.exe
After running ShutdownPerformanceView, the main window displays the
shutdown performance information of the current running system. If you
want to view the shutdown performance information of another system, go
to File -> Choose Data Source (or simply press F7), and then choose the
desired data source (External events folder or remote computer).



Command-Line options
====================




/stext <Filename>
Save the shutdown performance records to a simple text file.

/stab <Filename>
Save the shutdown performance records to a tab-delimited text file.

/scomma <Filename>
Save the shutdown performance records to a comma-delimited text file
(csv).

/shtml <Filename>
Save the shutdown performance records to HTML5 file (Horizontal).

/sverhtml <Filename>
Save the shutdown performance records to HTML5 file (Vertical).

/sxml <Filename>
Save the shutdown performance records to XML file.

/sjson <Filename>
Save the shutdown performance records to JSON file.

/sort <column>
This command-line option can be used with other save options for sorting
by the desired column. The <column> parameter can specify the column
index (0 for the first column, 1 for the second column, and so on) or the
name of the column, like "Record ID" and "Shutdown Time". You can specify
the '~' prefix character (e.g: "~Shutdown Time") if you want to sort in
descending order. You can put multiple /sort in the command-line if you
want to sort by multiple columns.

/cfg <Config Filename&gt
Start ShutdownPerformanceView with the specified config file.

/Columns <Comma Delimited Columns List>
Allows you to set the columns to display or the columns to export from
command-line. You have to specify the column names, delimited by comma,
for example:
ShutdownPerformanceView.exe /scomma c:\temp\shutdown-performance.csv
/Columns "Record ID,Shutdown Start Time,Shutdown End Time,Shutdown Time"

You can also specify the column names without space characters, for
example:
ShutdownPerformanceView.exe /Columns
"RecordID,ShutdownStartTime,ShutdownEndTime,ShutdownTime"



Translating ShutdownPerformanceView to other languages
======================================================

In order to translate ShutdownPerformanceView to other language, follow
the instructions below:
1. Run ShutdownPerformanceView with /savelangfile parameter:
   ShutdownPerformanceView.exe /savelangfile
   A file named ShutdownPerformanceView_lng.ini will be created in the
   folder of ShutdownPerformanceView utility.
2. Open the created language file in Notepad or in any other text
   editor.
3. Translate all string entries to the desired language. Optionally,
   you can also add your name and/or a link to your Web site.
   (TranslatorName and TranslatorURL values) If you add this information,
   it'll be used in the 'About' window.
4. After you finish the translation, Run ShutdownPerformanceView, and
   all translated strings will be loaded from the language file.
   If you want to run ShutdownPerformanceView without the translation,
   simply rename the language file, or move it to another folder.



License
=======

This utility is released as freeware. You are allowed to freely
distribute this utility via CD-ROM, DVD, Internet, or in any other way,
as long as you don't charge anything for this and you don't sell it or
distribute it as a part of commercial product. If you distribute this
utility, you must include all files in the distribution package, without
any modification !



Disclaimer
==========

The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be liable for any special, incidental, consequential or indirect damages
due to loss of data or any other reason.



Feedback
========

If you have any problem, suggestion, comment, or you found a bug in my
utility, you can send a message to support@nirsoft.net
