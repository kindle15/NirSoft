


WinMailPassRec v1.01
Copyright (c) 2022 - 2024 Nir Sofer
Web site:
https://www.nirsoft.net/utils/windows_mail_password_recovery.html



Description
===========

WinMailPassRec is a password recovery tool for Windows 10 and Windows 11
that displays the details of all POP3/IMAP/SMTP/Exchange accounts stored
in the mail application of Windows operating system. For every account,
the following information is displayed: Account Name, Email, Mailbox
Type, Mail Server, User, Password, Outgoing Server, Outgoing Server
Password, Account Creation Time, Last Used Time, Last Sync Attempt Time,
Last Sync Success Time.



System Requirements
===================

This tool works with the built-in mail application of Windows 10 and
Windows 11. Both 32-bit and 64-bit systems are supported.
You can also use this tool on older versions of Windows (like Windows 7)
for recovering data from external disk with Windows 10 or Windows 11.
Be aware that WinMailPassRec can only recover the passwords of
POP3/IMAP/SMTP/Exchange accounts. It cannot recover the passwords for
other types of accounts like Microsoft account or Gmail.



Version History
===============


* Version 1.01:
  o Fixed a problem with decrypting Windows Mail passwords from
    external drive on Windows 11 22H2.

* Version 1.00 - First release.



General Information
===================

The mail App of Windows 10 and Windows 11 stores the
POP3/IMAP/SMTP/Exchange accounts information in 2 different places:
1. Under the following Registry key:
   HKEY_CURRENT_USER\Software\Microsoft\ActiveSync\Partners (Every
   account on different subkey) - Most of the account information is
   stored under this Registry key, but without the server and password
   information.
2. The passwords and server information are encrypted and stored
   inside Windows Vault (Located under the following folder:
   %LocalAppData%\Microsoft\Vault\4BF4C442-9B8A-41A0-B380-DD4A704DDB28 )

WinMailPassRec combines the information from the above 2 places.



Start Using WinMailPassRec
==========================

WinMailPassRec doesn't require any installation process or additional DLL
files. In order to start using it, simply run the executable file -
WinMailPassRec.exe
After running WinMailPassRec, the 'Advanced Options' window is opened,
and then you can choose to load the Windows Mail accounts from your
current user, or from external hard drive plugged to your computer. If
you choose to load the Windows Mail accounts from external disk, you have
to fill more fields in order to decrypt the mail passwords.
After choosing the desired option, click the 'OK' button, and
WinMailPassRec will display your Windows Mail accounts in the main
window. You can select one or more mail accounts (or press Ctrl+A to
select all) and then export the list to
comma-delimited/tab-delimited/HTML/XML/JSON file by using the 'Save
Selected Items' option (Ctrl+S). You can also copy the email accounts
list to the clipboard (Ctrl+C) and then paste them to Excel or other
application.



View Windows Mail accounts on external drive
============================================

If you want to recover the passwords and other details of Windows Mail
accounts stored on external disk plugged to your computer, choose
'External Disk' in the 'Load From' combo-box of the 'Advanced Options'
window, and then fill the other fields: The login password of the user,
Protect folder of the user profile (e.g:
G:\Users\user10\AppData\Roaming\Microsoft\Protect ), Vault folder of the
user profile (e.g: G:\Users\user10\AppData\Local\Microsoft\Vault ), and
the Registry file of the user profile (e.g: G:\Users\user10\ntuser.dat ).
Be aware that if Microsoft account was used to login, you have to extract
the actual decryption password with the MadPassExt tool and then paste
this password into the login password field.

You may also need to run this tool as Administrator (Ctrl+F11) in order
to allow it to read the files from the user profile. If WinMailPassRec
cannot read the files, error message will be displayed in the bottom
status bar.



Translating WinMailPassRec to other languages
=============================================

In order to translate WinMailPassRec to other language, follow the
instructions below:
1. Run WinMailPassRec with /savelangfile parameter:
   WinMailPassRec.exe /savelangfile
   A file named WinMailPassRec_lng.ini will be created in the folder of
   WinMailPassRec utility.
2. Open the created language file in Notepad or in any other text
   editor.
3. Translate all string entries to the desired language. Optionally,
   you can also add your name and/or a link to your Web site.
   (TranslatorName and TranslatorURL values) If you add this information,
   it'll be used in the 'About' window.
4. After you finish the translation, Run WinMailPassRec.exe, and all
   translated strings will be loaded from the language file.
   If you want to run WinMailPassRec without the translation, simply
   rename the language file, or move it to another folder.



License
=======

This utility is released as freeware. You are allowed to freely
distribute this utility via CD-ROM, DVD, Internet, or in any other way,
as long as you don't charge anything for this and you don't sell it or
distribute it as a part of commercial product. If you distribute this
utility, you must include all files in the distribution package, without
any modification !



Disclaimer
==========

The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be liable for any special, incidental, consequential or indirect damages
due to loss of data or any other reason.



Feedback
========

If you have any problem, suggestion, comment, or you found a bug in my
utility, you can send a message to support@nirsoft.net
