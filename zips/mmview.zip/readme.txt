**********************************
MMCompView v1.10
Copyright (c) 2003 Nir Sofer

Web site: http://nirsoft.cjb.net
**********************************


Description
===========
The MMCompView utility displays the details of all installed multimedia components
(Codec and ActiveX filters) and allows you to disable and enable specific components.


License
=======
This utility is released as freeware for personal and non-commercial use. 
You are allowed to freely distribute this utility via floppy disk, CD-ROM, 
Internet, or in any other way, as long as you don't charge anything for this.  
If you distribute this utility, you must include the 'readme.txt' file in
the distribution package, without any modification !


Disclaimer
==========
The software is provided "AS IS" without any warranty, either expressed 
or implied, including, but not limited to, the implied warranties of 
merchantability and fitness for a particular purpose. The author will not 
be liable for any special, incidental, consequential or indirect damages 
due to loss of data or any other reason. 


Using the MMCompView utility
============================
This utility is a standalone executable. It doesn't require any installation process
or additional DLLs. Just run the executable (mmview.exe) and all installed 
multimedia components will be displayed.



Disable and enable multimedia components
========================================
If you install multiple Codec packages and other multimedia software on the same
computer, you might find out that some multimedia files are not played properly 
as before. This problem is occurred if Windows Media Player uses the codec
or filter of the newly installed multimedia software.
If you install a new Codec package and something goes wrong, you can try to fix 
the problem disabling the newly installed components.


Command-line options
=====================
/stext <Filename>
Save the details of all multimedia components into a regular text file.

/stab <Filename>
Save the details of all multimedia components into a tab-delimited text file.

/stabular <Filename>
Save the details of all multimedia components into a tabular text file.

/shtml <Filename>
Save the details of all multimedia components into HTML file.


Feedback
========
If you have any problem, suggestion, comment, or you found a bug in my 
utility, you can send a message to nirsofer@yahoo.com

